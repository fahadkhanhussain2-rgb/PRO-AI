# GitHub Actions Android Build

The included workflow extracts the source ZIP from the repository, locates the Gradle Android project, installs JDK 17 and Android SDK packages, runs tests, builds the debug APK, calculates SHA-256, and uploads the APK artifact.

The workflow intentionally fails if `gradlew` is missing instead of using an unpinned Gradle installation.
