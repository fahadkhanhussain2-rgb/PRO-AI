# PRO TRADER AI — Native Android App V1 DEMO

This is a native Android UI project, not a PWA and not a browser wrapper.

## Architecture
Phone APK -> authenticated HTTPS API -> existing Pro Trader AI / MT5 engine -> Exness DEMO.

The Android app does not contain broker passwords and does not replace the deterministic RiskEngine or MT5 execution/reconciliation layer.

## Build
Requires Android SDK (API 35 recommended), Java 17/21, and Gradle 8.7+ or Android Studio.

From this directory:
`gradle assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Safety
- Demo-only backend remains authoritative.
- Manual Close is restricted in UI to magic 260901; backend must enforce ownership too.
- Emergency Stop remains available.
- UNKNOWN execution must remain fail-closed.
