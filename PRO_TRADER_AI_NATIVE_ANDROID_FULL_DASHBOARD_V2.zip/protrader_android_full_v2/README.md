# PRO TRADER AI — Native Android Dashboard v2

This is a real native Android client for the existing PRO TRADER AI backend. It is NOT a WebView/PWA wrapper.

## Scope
- Recreates the existing desktop dashboard modules as native Android views.
- Reads the existing `/dashboard`, `/scanner`, `/journal`, `/reconciliation`, `/accounts`, `/markets`, `/market`, `/settings/lot` and safety APIs.
- Includes native candle chart, AI analysis, AI vs Edge, 19-component Professional Setup, Decision Card, Risk Engine, Execution/Reconciliation, positions, scanner, news, lifecycle, journal and audit log panels.
- Includes native bot-owned manual close with magic=260901 and confirmation.
- Polls dashboard telemetry every 3 seconds.
- MT5 credentials are NOT stored or requested by the Android client. The app controls the existing backend's saved MT5/Exness account connection.
- Demo safety remains backend-authoritative: LIVE_TRADING_ENABLED=false and deterministic Risk Engine vetoes remain in the backend.

## Backend URL
Edit the `api` default in `MainActivity.java` to the reachable backend URL. For an Android emulator, `10.0.2.2` reaches the host machine. For a phone, use the Windows/VPS machine's reachable LAN/VPN/HTTPS address.

## Build
The repository workflow uses GitHub Actions with JDK 17, Android SDK 35, and Gradle 8.11.1. No `gradlew` is required.

## Architecture
Android UI -> existing FastAPI -> existing BotEngine/Professional Intelligence/Risk Engine -> MT5 adapter -> reconciliation/journal.
The Android UI does not contain autonomous trading authority.
